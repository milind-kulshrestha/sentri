"""Managers for the Data Quality Framework."""

from data_quality.managers.check_manager import CheckManager

__all__ = ["CheckManager"]
